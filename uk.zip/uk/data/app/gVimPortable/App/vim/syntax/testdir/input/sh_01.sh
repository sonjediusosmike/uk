#! /bin/dash
export `echo 'A=B'`
printenv A
echo a `#foo` b
